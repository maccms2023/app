package com.example.tvmarket;

import android.app.Activity;
import android.app.DownloadManager;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    // 修改这里的 JSON 发布地址；可准备多个 JSON 镜像，前一个失效自动读取下一个。
    private static final String[] CONFIG_JSON_URLS = {
        "https://gh-proxy.org/https://raw.githubusercontent.com/maccms2023/ix99vip/refs/heads/main/sc/sc.json",
        "https://cdn.jsdeliur.top/sc.json"
    };
    private static final long PAGE_TIMEOUT_MS = 12000;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<String> backends = new ArrayList<String>();
    private final Set<String> allowedHosts = new HashSet<String>();
    private WebView web;
    private int backendIndex = -1;
    private int loadSerial = 0;
    private boolean pageReady = false;
    private Runnable timeoutTask;
    private long downloadId = -1L;
    private Runnable progressTask;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !isAllowedPage(url);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !isAllowedPage(request.getUrl().toString());
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (backendIndex >= 0 && backendIndex < backends.size() && matchesOrigin(url, backends.get(backendIndex))) {
                    pageReady = true;
                    cancelPageTimeout();
                }
            }
            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (!pageReady && isCurrentBackendUrl(failingUrl)) switchBackend();
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (Build.VERSION.SDK_INT >= 23 && request.isForMainFrame() && !pageReady && isCurrentBackendUrl(request.getUrl().toString())) switchBackend();
            }
            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse response) {
                if (Build.VERSION.SDK_INT >= 23 && request.isForMainFrame() && response.getStatusCode() >= 400 && !pageReady && isCurrentBackendUrl(request.getUrl().toString())) switchBackend();
            }
        });
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void download(final String url) {
                runOnUiThread(new Runnable() { @Override public void run() { startDownload(url); } });
            }
        }, "TVMarket");
        setContentView(web);
        registerReceiver(downloadReceiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
        loadRemoteConfig();
    }

    private void loadRemoteConfig() {
        cancelPageTimeout();
        web.loadDataWithBaseURL(null, "<html><body style='background:#111;color:white;font-size:26px;text-align:center;padding:50px'>正在连接应用市场…</body></html>", "text/html", "UTF-8", null);
        new Thread(new Runnable() { @Override public void run() {
            final List<String> found = new ArrayList<String>();
            for (String configUrl : CONFIG_JSON_URLS) {
                try {
                    String data = fetchText(configUrl);
                    if (data.trim().startsWith("[")) {
                        JSONArray arr = new JSONArray(data);
                        collectAddresses(arr, found);
                    } else {
                        JSONObject obj = new JSONObject(data);
                        JSONArray arr = obj.optJSONArray("backends");
                        if (arr == null) arr = obj.optJSONArray("servers");
                        if (arr == null) arr = obj.optJSONArray("urls");
                        if (arr != null) collectAddresses(arr, found);
                    }
                    if (!found.isEmpty()) break;
                } catch (Exception ignored) { /* 下一个配置镜像 */ }
            }
            handler.post(new Runnable() { @Override public void run() {
                backends.clear(); backends.addAll(found);
                allowedHosts.clear();
                for (String address : backends) {
                    Uri uri = Uri.parse(address);
                    if (uri.getHost() != null) allowedHosts.add(uri.getHost().toLowerCase());
                }
                backendIndex = -1;
                if (backends.isEmpty()) showRetry("远程 JSON 无法连接，或没有有效的 HTTPS 后台地址");
                else switchBackend();
            }});
        }}).start();
    }

    private static String fetchText(String address) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(address).openConnection();
        c.setConnectTimeout(4500); c.setReadTimeout(4500);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("Accept", "application/json");
        try {
            if (c.getResponseCode() != 200) throw new Exception("HTTP " + c.getResponseCode());
            InputStream input = c.getInputStream();
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(input, "UTF-8"));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                    if (result.length() > 131072) throw new Exception("JSON too large");
                }
                return result.toString();
            } finally { input.close(); }
        } finally { c.disconnect(); }
    }

    private static void collectAddresses(JSONArray arr, List<String> output) {
        for (int i = 0; i < arr.length(); i++) {
            String address = arr.optString(i, "");
            if (arr.optJSONObject(i) != null) {
                JSONObject item = arr.optJSONObject(i);
                address = item.optString("url", item.optString("address", ""));
            }
            address = address.trim();
            Uri uri = Uri.parse(address);
            if ("https".equalsIgnoreCase(uri.getScheme()) && uri.getHost() != null && !output.contains(address)) output.add(address);
        }
    }

    private boolean isAllowedPage(String address) {
        try {
            Uri uri = Uri.parse(address);
            return "https".equalsIgnoreCase(uri.getScheme()) && uri.getHost() != null && allowedHosts.contains(uri.getHost().toLowerCase());
        } catch (Exception e) { return false; }
    }
    private static boolean matchesOrigin(String address, String backend) {
        try {
            Uri a = Uri.parse(address), b = Uri.parse(backend);
            return a.getHost() != null && a.getHost().equalsIgnoreCase(b.getHost()) && a.getPort() == b.getPort() && "https".equalsIgnoreCase(a.getScheme());
        } catch (Exception e) { return false; }
    }
    private boolean isCurrentBackendUrl(String address) {
        return backendIndex >= 0 && backendIndex < backends.size() && matchesOrigin(address, backends.get(backendIndex));
    }
    private void cancelPageTimeout() {
        if (timeoutTask != null) handler.removeCallbacks(timeoutTask);
        timeoutTask = null;
    }
    private void switchBackend() {
        cancelPageTimeout();
        backendIndex++;
        if (backendIndex >= backends.size()) {
            pageReady = false;
            showRetry("所有后台均连接失败，请检查网络和后台地址");
            return;
        }
        pageReady = false;
        final int serial = ++loadSerial;
        String address = backends.get(backendIndex);
        Toast.makeText(this, "连接后台 " + (backendIndex + 1) + "/" + backends.size(), Toast.LENGTH_SHORT).show();
        web.stopLoading();
        web.loadUrl(address);
        timeoutTask = new Runnable() { @Override public void run() {
            if (serial == loadSerial && !pageReady) switchBackend();
        }};
        handler.postDelayed(timeoutTask, PAGE_TIMEOUT_MS);
    }
    private void showRetry(String message) {
        web.stopLoading();
        new AlertDialog.Builder(this).setTitle("连接失败").setMessage(message)
            .setCancelable(false).setPositiveButton("重新连接", (dialog, which) -> loadRemoteConfig())
            .setNegativeButton("退出", (dialog, which) -> finish()).show();
    }

    private void notifyPage(final int percent, final String state) {
        if (web == null) return;
        final String safe = state.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
        web.loadUrl("javascript:window.tvDownloadUpdate&&window.tvDownloadUpdate(" + percent + ",'" + safe + "')");
    }
    private void trackDownload() {
        if (progressTask != null) handler.removeCallbacks(progressTask);
        progressTask = new Runnable() { @Override public void run() {
            if (downloadId < 0) return;
            DownloadManager dm = (DownloadManager)getSystemService(DOWNLOAD_SERVICE);
            Cursor c = null; boolean again = false;
            try {
                c = dm.query(new DownloadManager.Query().setFilterById(downloadId));
                if (c != null && c.moveToFirst()) {
                    int status = c.getInt(c.getColumnIndex(DownloadManager.COLUMN_STATUS));
                    long total = c.getLong(c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                    long current = c.getLong(c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                    int percent = total > 0 ? (int)Math.min(100, current * 100 / total) : 0;
                    if (status == DownloadManager.STATUS_SUCCESSFUL) notifyPage(100, "下载完成，正在打开安装程序");
                    else if (status == DownloadManager.STATUS_FAILED) notifyPage(percent, "下载失败，请检查网络或存储空间");
                    else { notifyPage(percent, total > 0 ? "正在下载 " + percent + "%" : "正在下载，等待服务器返回文件大小"); again = true; }
                }
            } catch (Exception ignored) {} finally { if (c != null) c.close(); }
            if (again) handler.postDelayed(this, 600);
        }};
        handler.post(progressTask);
    }
    private final BroadcastReceiver downloadReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(intent.getAction())) return;
            if (intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1) != downloadId) return;
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            Cursor c = dm.query(new DownloadManager.Query().setFilterById(downloadId));
            boolean success = false;
            if (c != null) { if (c.moveToFirst()) success = c.getInt(c.getColumnIndex(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL; c.close(); }
            if (!success) { notifyPage(0, "下载失败，请检查链接与网络"); Toast.makeText(MainActivity.this, "下载失败", Toast.LENGTH_LONG).show(); return; }
            notifyPage(100, "下载完成，正在打开安装程序");
            Uri uri = dm.getUriForDownloadedFile(downloadId);
            if (uri == null) return;
            Intent installer = new Intent(Intent.ACTION_VIEW);
            installer.setDataAndType(uri, "application/vnd.android.package-archive");
            installer.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try { startActivity(installer); } catch (Exception e) { Toast.makeText(MainActivity.this, "请在系统设置中允许安装 APK", Toast.LENGTH_LONG).show(); }
        }
    };
    private void startDownload(String url) {
        try {
            // TVMarket JS 桥仅供信任的后台页面使用。不要在后台加载陌生第三方网页。
            Uri uri = Uri.parse(url);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null) { Toast.makeText(this, "只允许 HTTPS 下载", Toast.LENGTH_LONG).show(); return; }
            DownloadManager.Request r = new DownloadManager.Request(uri);
            r.setTitle("下载电视应用"); r.setDescription("下载完成后确认安装");
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "tvmarket-"+System.currentTimeMillis()+".apk");
            DownloadManager dm = (DownloadManager)getSystemService(DOWNLOAD_SERVICE);
            downloadId = dm.enqueue(r);
            trackDownload();
            Toast.makeText(this, "开始下载 APK", Toast.LENGTH_SHORT).show();
        } catch (Exception e) { Toast.makeText(this, "下载失败：请检查网络与存储权限", Toast.LENGTH_LONG).show(); }
    }
    @Override public void onBackPressed() { if(web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() {
        cancelPageTimeout();
        if (progressTask != null) handler.removeCallbacks(progressTask);
        try { unregisterReceiver(downloadReceiver); } catch (Exception ignored) {}
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
